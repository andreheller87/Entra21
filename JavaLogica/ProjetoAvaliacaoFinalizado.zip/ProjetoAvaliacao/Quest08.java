
/**
  Crie um algoritmo que leia uma frase do usuário e escreva na tela exatamente o que o usuário digitar.   
 */
import java.util.Scanner;
public class Quest08
{

   public static void main(String []args){
       Scanner in = new Scanner(System.in);
       String str = "";
       System.out.println("Digite uma frase");
       str = in.nextLine();
       
      
       
       
       System.out.printf(str);
   }
}


