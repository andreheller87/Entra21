//rie um algoritmo que escreve o seu nome completo,
// colocando uma palavra em cada linha.   
public class Quest01
{
    public static void main(String []args){
        String nome = "André";
        String sobreNome = "Heller";
        
        
        System.out.println(nome);
        System.out.println(sobreNome);
    }
}
