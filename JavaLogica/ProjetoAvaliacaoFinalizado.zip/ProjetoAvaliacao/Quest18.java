
/**
 *18.	Escreva um algoritmo que exiba 20 vezes a mensagem “Eu gosto de estudar Algoritmos!”.
 *Utilize o comando de repetição Para (For).  
 */


public class Quest18
{
   

        public static void main (String args[]){
          
            for(int i=0; i<20;i++){
                System.out.println("Eu gosto de estudar Algoritmos!");
            }
            
            
}

   

}
